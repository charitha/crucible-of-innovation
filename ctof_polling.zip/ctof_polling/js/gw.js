var constants = {
    containers: [ "#c1_container","#c2_container","#c3_container"]
}




function make_ajax()
{
    return {"c3": [[16, 40], [17, 30], [18, 20], [19,10]],"c2": [[16, 40], [17, 30], [18, 20], [19,10], [20, 5]], "c1": [[16, 40], [17, 30], [18, 20], [19,10], [20, 5]]}
}


function filter_data(data){
    filtered = {"c1":{"team_name":[],"score":[]},"c2":{"team_name":[],"score":[]},"c3":{"team_name":[],"score":[]}}

    $.each(data,function(category_name,element){
        $.each(element,function(index,tuple){            
            filtered[category_name]["team_name"].push(tuple[0])
            filtered[category_name]["score"].push(tuple[1])
        })
    })
}



function get_chart_objects()
{
    chart_objects = {}
    //Initial drawing of the charts
    for (var i = 1; i <= 3; i++) {        
        var options = get_chart_options({"categories":filtered["c"+i]["team_name"]})                
        $(constants.containers[i-1]).highcharts(options)
        chart_objects["c"+i] = $(constants.containers[i-1]).highcharts()
    };
}

function set_data()
{
    data = make_ajax();
    filter_data(data);
    for (var i = 1; i <= 3; i++) {      
        chart_objects["c"+i].series[0].setData(filtered["c"+i]["score"])
    };
    setTimeout(set_data,10000)
}

info = make_ajax()
filter_data(info)
get_chart_objects()
set_data()